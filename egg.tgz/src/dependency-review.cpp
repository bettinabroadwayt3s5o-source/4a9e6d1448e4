// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(int argc, char** argv){
  (void)argc; (void)argv;
  std::printf("%s\n", "dependency review");
  std::fflush(stdout);
  return lionss_run_workload("dependency-review");
}
