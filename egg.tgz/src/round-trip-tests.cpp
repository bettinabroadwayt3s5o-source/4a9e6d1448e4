// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("round trip tests"); }
int main(){
  announce();
  return lionss_run_workload("round-trip-tests");
}
