// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("headers selfcontained"); }
int main(){
  announce();
  return lionss_run_workload("headers-selfcontained");
}
