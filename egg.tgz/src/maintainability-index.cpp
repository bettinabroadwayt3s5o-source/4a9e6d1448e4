// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("maintainability index"); }
int main(){
  announce();
  return lionss_run_workload("maintainability-index");
}
